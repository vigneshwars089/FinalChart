function viewchart1(){
  console.log("enter");
  // to load dropdown value
  var select = document.getElementById("2dim_dropdown1");
  var options = headArray;
  for(var i = 0; i < options.length; i++) {
      var opt = options[i];
      var el = document.createElement("option");
      el.textContent = opt;
      el.value = opt;
      select.appendChild(el);
  }
  var select = document.getElementById("2dim_dropdown2");
  var options = headArray;
  for(var i = 0; i < options.length; i++) {
      var opt = options[i];
      var el = document.createElement("option");
      el.textContent = opt;
      el.value = opt;
      select.appendChild(el);
  }
  document.getElementById('axis_div1').style.display='block';
  document.getElementById('axis_div2').style.display='none';
  document.getElementById('axis_div3').style.display='none';
  document.getElementById('axis_div4').style.display='none';



  var radioBtn = $('<div id="mychart" style="margin-left: 20%;margin-top: 4%;"><label><input type="radio"  name="example" value="Pie Chart"/>Pie Chart</label><label><input type="radio"  name="example" value="Column Chart"/>Column Chart</label><label><input type="radio"  name="example" value="Donut Chart" />Donut Chart</label></div>');
     $('#Chart_div').empty().append(radioBtn);
};
function viewchart2(){
  document.getElementById('axis_div2').style.display='block';
  document.getElementById('axis_div1').style.display='none';
  document.getElementById('axis_div3').style.display='none';
  document.getElementById('axis_div4').style.display='none';

  console.log("enter");
  var radioBtn = $('<div id="mychart2" style="margin-left: 20%;margin-top: 4%;"><label><input type="radio"  name="example2" value="Stacked chart"/>Stacked chart</label><label><input type="radio"  name="example2" value="Area chart" />Area chart</label><label><input type="radio"  name="example2" value="Line Chart" />Line Chart</label></div>');
     $('#Chart_div').empty().append(radioBtn);
};
// function viewchart3(){
//   console.log("enter");
//   var radioBtn = $('<div id="mychart3" style="margin-left: 20%;margin-top: 4%;"><label><input type="radio"  name="example3" value="Candle Chart" />CandleStick Chart</label></div>');
//      $('#Chart_div').empty().append(radioBtn);
// };
function viewchart4(){
  var select = document.getElementById("3dim1");
  var options = headArray;
  for(var i = 0; i < options.length; i++) {
      var opt = options[i];
      var el = document.createElement("option");
      el.textContent = opt;
      el.value = opt;
      select.appendChild(el);
  }
  document.getElementById('axis_div3').style.display='block';
  document.getElementById('axis_div1').style.display='none';
  document.getElementById('axis_div2').style.display='none';
  document.getElementById('axis_div4').style.display='none';

  console.log("enter");
  var radioBtn = $('<div id="mychart4" style="margin-left: 20%;margin-top: 4%;"><label><input type="radio"  name="example4" value="Scatter chart" />Scatter chart</label></div>');
     $('#Chart_div').empty().append(radioBtn);
};
function viewchart5(){
  document.getElementById('axis_div4').style.display='block';
  document.getElementById('axis_div1').style.display='none';
  document.getElementById('axis_div2').style.display='none';
  document.getElementById('axis_div3').style.display='none';

  console.log("enter");
  var radioBtn = $('<div id="mychart4" style="margin-left: 20%;margin-top: 4%;"><label><input type="radio"  name="example5" value="Line-Bar chart" />Line-Bar chart</label><label><input type="radio"  name="example5" value="Bar-Line chart" />Bar-Line chart</label><label><input type="radio"  name="example5" value="Area-Bar chart" />Area-Bar chart</label><label><input type="radio"  name="example5" value="Bar-Area chart" />Bar-Area chart</label><label><input type="radio"  name="example5" value="Area-Line chart" />Area-Line chart</label><label><input type="radio"  name="example5" value="Line-Area chart" />Line-Area chart</label></div>');
     $('#Chart_div').empty().append(radioBtn);
};

// $('#mychart input').on('change', function() {
//    alert($('input[name="myRadio"]:checked', '#myForm').val());
// });

var Global_chart_data = {};
// console.log(Global_chart_data);
function get_data(){
    $.getJSON("./ChartInput.json", function(jsonObj){
      // var jsonObj = {};
        for(var k in jsonObj)
        {
          Global_chart_data[k] = jsonObj[k] ;
        }
        console.log(Global_chart_data);

  });
}
var dropdownvalue;
// function datafilter(dropdownvalue)
// {
//
// var filterhead=headArray.indexOf(dropdownvalue);
//
// console.log(filterhead);
//
// }

var ChartName;
function drawchart(ChartName)
{
 console.log(ChartName);



 if(ChartName=="Line-Bar chart")
 {
   console.log(ChartName);
   $('#chartdraw_div').empty();

 document.getElementById('chartdraw_div').style.display='block';
 google.charts.load('current', {'packages':['corechart']});
 google.charts.setOnLoadCallback(drawVisualization);

 function drawVisualization() {
   // Some raw data (not necessarily accurate)

   var jsonObj = {};
                for(var k in Global_chart_data)
                 {
                  jsonObj[k] = Global_chart_data[k];
            }
            var data = google.visualization.arrayToDataTable(jsonObj['comboData']);
var options = {
 title : 'Monthly Coffee Production by Country',
 vAxis: {title: 'Cups'},
 hAxis: {title: 'Month'},
 seriesType: 'line',
 series: {5: {type: 'bars'}}
};

var chart = new google.visualization.ComboChart(document.getElementById('chartdraw_div'));
chart.draw(data, options);
}
}
if(ChartName=="Bar-Line chart")
{
  console.log(ChartName);
  $('#chartdraw_div').empty();

document.getElementById('chartdraw_div').style.display='block';
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawVisualization);

function drawVisualization() {
  // Some raw data (not necessarily accurate)

  var jsonObj = {};
               for(var k in Global_chart_data)
                {
                 jsonObj[k] = Global_chart_data[k];
           }
           var data = google.visualization.arrayToDataTable(jsonObj['comboData']);
var options = {
title : 'Monthly Coffee Production by Country',
vAxis: {title: 'Cups'},
hAxis: {title: 'Month'},
seriesType: 'bars',
series: {5: {type: 'line'}}
};

var chart = new google.visualization.ComboChart(document.getElementById('chartdraw_div'));
chart.draw(data, options);
}
}
if(ChartName=="Area-Bar chart")
{
  console.log(ChartName);
  $('#chartdraw_div').empty();

document.getElementById('chartdraw_div').style.display='block';
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawVisualization);

function drawVisualization() {
  // Some raw data (not necessarily accurate)

  var jsonObj = {};
               for(var k in Global_chart_data)
                {
                 jsonObj[k] = Global_chart_data[k];
           }
           var data = google.visualization.arrayToDataTable(jsonObj['comboData']);
var options = {
title : 'Monthly Coffee Production by Country',
vAxis: {title: 'Cups'},
hAxis: {title: 'Month'},
seriesType: 'area',
series: {5: {type: 'bars'}}
};

var chart = new google.visualization.ComboChart(document.getElementById('chartdraw_div'));
chart.draw(data, options);
}
}
if(ChartName=="Bar-Area chart")
{
  console.log(ChartName);
  $('#chartdraw_div').empty();

document.getElementById('chartdraw_div').style.display='block';
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawVisualization);

function drawVisualization() {
  // Some raw data (not necessarily accurate)

  var jsonObj = {};
               for(var k in Global_chart_data)
                {
                 jsonObj[k] = Global_chart_data[k];
           }
           var data = google.visualization.arrayToDataTable(jsonObj['comboData']);
var options = {
title : 'Monthly Coffee Production by Country',
vAxis: {title: 'Cups'},
hAxis: {title: 'Month'},
seriesType: 'bars',
series: {5: {type: 'area'}}
};

var chart = new google.visualization.ComboChart(document.getElementById('chartdraw_div'));
chart.draw(data, options);
}
}
if(ChartName=="Area-Line chart")
{
  console.log(ChartName);
  $('#chartdraw_div').empty();

document.getElementById('chartdraw_div').style.display='block';
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawVisualization);

function drawVisualization() {
  // Some raw data (not necessarily accurate)

  var jsonObj = {};
               for(var k in Global_chart_data)
                {
                 jsonObj[k] = Global_chart_data[k];
           }
           var data = google.visualization.arrayToDataTable(jsonObj['comboData']);

                 var options = {
title : 'Monthly Coffee Production by Country',
vAxis: {title: 'Cups'},
hAxis: {title: 'Month'},
seriesType: 'area',
series: {5: {type: 'line'}}
};

var chart = new google.visualization.ComboChart(document.getElementById('chartdraw_div'));
chart.draw(data, options);
}
}
if(ChartName=="Line-Area chart")
{
  console.log(ChartName);
  $('#chartdraw_div').empty();

document.getElementById('chartdraw_div').style.display='block';
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawVisualization);

function drawVisualization() {
  // Some raw data (not necessarily accurate)

  var jsonObj = {};
               for(var k in Global_chart_data)
                {
                 jsonObj[k] = Global_chart_data[k];
           }
console.log(jsonObj);
var data = google.visualization.arrayToDataTable(jsonObj['comboData']);
  console.log(data);
var options = {
title : 'Monthly Coffee Production by Country',
vAxis: {title: 'Cups'},
hAxis: {title: 'Month'},
seriesType: 'line',
series: {5: {type: 'area'}}
};

var chart = new google.visualization.ComboChart(document.getElementById('chartdraw_div'));
chart.draw(data, options);
}
}






 else if(ChartName=="Scatter chart")
 {
   console.log(ChartName);
   $('#chartdraw_div').empty();

 document.getElementById('chartdraw_div').style.display='block';

 google.charts.load('current', {'packages':['scatter']});
 google.charts.setOnLoadCallback(drawChart);

 function drawChart () {
   var jsonObj = {};
                for(var k in Global_chart_data)
                 {
                  jsonObj[k] = Global_chart_data[k];
            }
            var data = google.visualization.arrayToDataTable(jsonObj['scatterData']);
  //  data.addColumn('number', 'Hours Studied');
  //  data.addColumn('number', 'Final');
   //
  //  data.addRows([
  //    [0, 67], [1, 88], [2, 77],
  //    [3, 93], [4, 85], [5, 91],
  //    [6, 71], [7, 78], [8, 93],
  //    [9, 80], [10, 82],[0, 75],
  //    [5, 80], [3, 90], [1, 72],
  //    [5, 75], [6, 68], [7, 98],
  //    [3, 82], [9, 94], [2, 79],
  //    [2, 95], [2, 86], [3, 67],
  //    [4, 60], [2, 80], [6, 92],
  //    [2, 81], [8, 79], [9, 83],
  //    [3, 75], [1, 80], [3, 71],
  //    [3, 89], [4, 92], [5, 85],
  //    [6, 92], [7, 78], [6, 95],
  //    [3, 81], [0, 64], [4, 85],
  //    [2, 83], [3, 96], [4, 77],
  //    [5, 89], [4, 89], [7, 84],
  //    [4, 92], [9, 98]
  //  ]);

   var options = {
     width: 800,
     height: 500,
     chart: {
       title: 'Students\' Final Grades',
       subtitle: 'based on hours studied'
     },
     hAxis: {title: 'Hours Studied'},
     vAxis: {title: 'Grade'}
   };

   var chart = new google.charts.Scatter(document.getElementById('chartdraw_div'));

   chart.draw(data, google.charts.Scatter.convertOptions(options));
 }

}














//---------------------------------------------STACKED CHART XY Y
else if(ChartName=="Stacked chart")
{
  console.log(ChartName);
  $('#chartdraw_div').empty();

document.getElementById('chartdraw_div').style.display='block';
google.charts.load("current", {packages:['corechart']});
google.charts.setOnLoadCallback(drawChart);
  function drawChart() {



     var jsonObj = {};
                  for(var k in Global_chart_data)
                   {
                    jsonObj[k] = Global_chart_data[k];
              }
             console.log(jsonObj.pieData);

    var Columndata = google.visualization.arrayToDataTable(jsonObj['ThirdData']);


    var view = new google.visualization.DataView(Columndata);
    view.setColumns([0, 1,
                     { calc: "stringify",
                       sourceColumn: 1,
                       type: "string",
                       role: "annotation" },
                     2]);

    var options = {
    width:400,
      height: 300,
      legend: { position: 'top', maxLines: 3 },
      bar: { groupWidth: '50%' },
      isStacked: true,
    };
    var chart = new google.visualization.ColumnChart(document.getElementById("chartdraw_div"));
    chart.draw(view, options);
}


}




























  //----------------------------------------------Area GRAPH X Y Y
else if(ChartName=="Area chart"){
  $('#chartdraw_div').empty();

  document.getElementById('chartdraw_div').style.display='block';
  google.charts.load('current', {'packages':['corechart']});
  google.charts.setOnLoadCallback(drawChart);

  function drawChart() {
    var jsonObj = {};
                 for(var k in Global_chart_data)
                  {
                   jsonObj[k] = Global_chart_data[k];
             }
            console.log(jsonObj.pieData);


    var options = {
      title: 'Company Performance',
      hAxis: {title: 'Year',  titleTextStyle: {color: '#333'}},
      vAxis: {minValue: 0}
    };
      var AreaData = google.visualization.arrayToDataTable(jsonObj['ThirdData']);

    var chart = new google.visualization.AreaChart(document.getElementById('chartdraw_div'));
    chart.draw(AreaData, options);
  }
}


























  //--------------------------------------------COLUMN CHART
else if(ChartName=="Column Chart"){
    $('#chartdraw_div').empty();

    document.getElementById('chartdraw_div').style.display='block';

  google.charts.load('current', {'packages':['bar']});
  google.charts.setOnLoadCallback(drawStuff);

  function drawStuff() {
    // var data = new google.visualization.arrayToDataTable([
    //   ['Move', 'Percentage'],
    //   ["King's pawn (e4)", 44],
    //   ["Queen's pawn (d4)", 31],
    //   ["Knight to King 3 (Nf3)", 12],
    //   ["Queen's bishop pawn (c4)", 10],
    //   ['Other', 3]
    // ]);
              var jsonObj = {};
                for(var k in Global_chart_data)
                {
                  jsonObj[k] = Global_chart_data[k];
                }
                console.log(jsonObj.pieData);
    var options = {
      width: 300,
      legend: { position: 'none' },
      chart: {
        title: 'Chess opening moves',
        subtitle: 'popularity by percentage' },
      axes: {
        x: {
          0: { side: 'top', label: 'White to move'} // Top x-axis.
        }
      },
      bar: { groupWidth: "60%" }
    };
    var Columndata = google.visualization.arrayToDataTable(jsonObj['columnData']);

    var chart = new google.charts.Bar(document.getElementById('chartdraw_div'));
    // Convert the Classic options to Material options.
    chart.draw(Columndata, google.charts.Bar.convertOptions(options));
  };

}


//----------------------------------------Donut Chart
else if(ChartName=="Donut Chart"){
  console.log(ChartName);

  $('#chartdraw_div').empty();

  document.getElementById('chartdraw_div').style.display='block';

google.charts.load("current", {packages:["corechart"]});
google.charts.setOnLoadCallback(drawChart);
function drawChart() {
  // var data = google.visualization.arrayToDataTable([
  //   ['Task', 'Hours per Day'],
  //   ['Work',     11],
  //   ['Eat',      2],
  //   ['Commute',  2],
  //   ['Watch TV', 2],
  //   ['Sleep',    7]
  // ]);
  var jsonObj = {};
    for(var k in Global_chart_data)
    {
      jsonObj[k] = Global_chart_data[k];
    }
  var options = {
    title: 'My Daily Activities',
    pieHole: 0.4,
  };
  var data = google.visualization.arrayToDataTable(jsonObj['pieData']);

  var chart = new google.visualization.PieChart(document.getElementById('chartdraw_div'));
  chart.draw(data, options);
}

}













//--------------------------------------------------PIE CHART
else if(ChartName=="Pie Chart"){
  console.log(ChartName);
  var e = document.getElementById("2dim_dropdown1");
var strUser = e.options[e.selectedIndex].text;
var e1 = document.getElementById("2dim_dropdown2");
var strUser1 = e1.options[e1.selectedIndex].text;
var x=headArray.indexOf(strUser);
var y=headArray.indexOf(strUser1);
var filterdata=[];
var tempdata=[];
console.log(x);
      for(var i=0; i<mystack.length; i++){
        var column = [];
        console.log(mystack);
         column.push(mystack[i][x]);
         column.push(mystack[i][y]);
         filterdata.push(column);
      }
      console.log(filterdata);
  $('#chartdraw_div').empty();

  document.getElementById('chartdraw_div').style.display='block';
  google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart1);
      function drawChart1() {

        // $.getJSON("Map_Data/ChartInput.json", function(jsonObj){
            // console.log(jsonObj.pieData);
            // var jsonObj = {};
            //   for(var k in Global_chart_data)
            //   {
            //     jsonObj[k] = Global_chart_data[k];
            //   }
            //   console.log(jsonObj.pieData);

        var Pieoptions = {
          title: 'Projects',
          is3D: true,

        };
        var Piedata = google.visualization.arrayToDataTable(filterdata);

        var chart = new google.visualization.PieChart(document.getElementById('chartdraw_div'));
        chart.draw(Piedata, Pieoptions);
      // });
    }

}

//-------------------------------------------------LINE CHART xy y
else if(ChartName=="Line Chart"){
  console.log(ChartName);
  $('#chartdraw_div').empty();

  document.getElementById('chartdraw_div').style.display='block';
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
  var jsonObj = {};
    for(var k in Global_chart_data)
    {
      jsonObj[k] = Global_chart_data[k];
    }
  //  console.log(jsonObj.pieData);

  var data = google.visualization.arrayToDataTable(jsonObj['ThirdData']);


  var options = {
    title: 'Company Performance',
    curveType: 'function',
    legend: { position: 'bottom' }
  };

  var chart = new google.visualization.LineChart(document.getElementById('chartdraw_div'));

  chart.draw(data, options);
}
}



















}
//----to convert json into html table

var myList = [
  { "Month": "2004/05", "Bolivia": 165, "Ecuador": 938, "Madagascar": 522, "Papua New Guinea": 998, "Rwanda": 450, "Average": 614.6 },
{ "Month": "2004/05", "Bolivia": 135, "Ecuador": 1120, "Madagascar": 599, "Papua New Guinea": 1268, "Rwanda": 288, "Average": 682 },
{ "Month": "2004/05", "Bolivia": 157, "Ecuador": 1167, "Madagascar": 587, "Papua New Guinea": 807, "Rwanda": 397, "Average": 623 },
{ "Month": "2004/05", "Bolivia": 139, "Ecuador": 1110, "Madagascar": 691, "Papua New Guinea": 968, "Rwanda": 215, "Average": 609.4 }
];
var mystack=[];
var headArray=[];

// var data=JSON.parse(myList);
// console.log(data);

// Builds the HTML Table out of myList.
function buildHtmlTable(selector) {
  var columns = addAllColumnHeaders(myList, selector);

  for (var i = 0; i < myList.length; i++) {
    var row$ = $('<tr/>');
    var temp=[];
    // alert(columns.length);
    for (var colIndex = 0; colIndex < columns.length; colIndex++) {
      var cellValue = myList[i][columns[colIndex]];
      console.log(cellValue);
      if (cellValue == null) cellValue = "";
      row$.append($('<td/>').html(cellValue));
      temp.push(cellValue);
      // alert(JSON.stringify(temp));
    }
    // alert("first end");
    mystack.push(temp);
    $(selector).append(row$);
  }

   alert(JSON.stringify(mystack));
}

// Adds a header row to the table and returns the set of columns.
// Need to do union of keys from all records as some records may not contain
// all records.
function addAllColumnHeaders(myList, selector) {
  var columnSet = [];
  var headerTr$ = $('<tr/>');
var temp=[];
  for (var i = 0; i < myList.length; i++) {
    var rowHash = myList[i];
    for (var key in rowHash) {
      if ($.inArray(key, columnSet) == -1) {
        columnSet.push(key);
        headerTr$.append($('<th/>').html(key));

      }
    }
  }
  headArray=columnSet;
  // alert(JSON.stringify(headArray));
mystack.push(columnSet);
  $(selector).append(headerTr$);

  return columnSet;

}
